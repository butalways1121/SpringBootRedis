package com.SpringBootRedis.dao;

import com.SpringBootRedis.entity.User;

public interface UserDao {
	void add(User user);//增加用户信息
	void update(User user);//更新用户信息
	void delete(int id);//删除用户
	User findById(int id);//根据id查找用户
}
