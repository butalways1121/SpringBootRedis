package com.SpringBootRedis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBootRedis.entity.User;
import com.SpringBootRedis.service.UserService;

@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	private UserService userService;

	// 增加用户
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public boolean addUser(@RequestBody User user) {
		System.out.println("开始增加用户信息！");
		return userService.add(user);
	}

	// 更新用户信息
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public boolean update(@RequestBody User user) {
		System.out.println("开始更新用户信息！");
		return userService.update(user);
	}

	// 删除用户
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public boolean delete(@RequestParam(value = "id",required = true) int id){
		System.out.println("开始删除用户！");
		return userService.delete(id);
	}
	
	
	//根据id查找用户信息
	@RequestMapping(value = "/findById", method = RequestMethod.GET)
	public User findById(@RequestParam(value = "id",required = true) int id){
		System.out.println("开始查找用户信息！");
		return userService.findById(id);
	}
}
