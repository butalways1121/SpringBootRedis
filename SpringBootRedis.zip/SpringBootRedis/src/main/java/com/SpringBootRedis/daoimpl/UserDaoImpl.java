package com.SpringBootRedis.daoimpl;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.SpringBootRedis.dao.UserDao;
import com.SpringBootRedis.entity.User;
import com.SpringBootRedis.util.RedisUtil;
import com.alibaba.fastjson.JSON;

//@Repository用于标注数据访问组件，即DAO组件
@Repository
public class UserDaoImpl implements UserDao {

	//@Resource注解就是把一个bean注入到当前的类中，可以不必通过配置文件或者导包的方式注入就可以使用该bean
	//@Resource的作用相当于@Autowired，只不过@Autowired按byType自动注入，而@Resource默认按 byName自动注入罢了
	@Resource
	private RedisUtil redisUtil;

	@Override
	public void add(User user) {
		// TODO 自动生成的方法存根
		redisUtil.set(String.valueOf(user.getId()), user.toString());
	}

	@Override
	public void update(User user) {
		// TODO 自动生成的方法存根
		redisUtil.set(String.valueOf(user.getId()), user.toString());
	}

	@Override
	public void delete(int id) {
		// TODO 自动生成的方法存根
		redisUtil.del(String.valueOf(id));
	}

	@Override
	public User findById(int id) {
		// TODO 自动生成的方法存根
		String data = redisUtil.get(String.valueOf(id)).toString();
		User user = JSON.parseObject(data, User.class);
		return user;
	}

}
