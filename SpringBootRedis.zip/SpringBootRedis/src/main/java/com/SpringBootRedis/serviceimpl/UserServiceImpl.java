package com.SpringBootRedis.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBootRedis.dao.UserDao;
import com.SpringBootRedis.entity.User;
import com.SpringBootRedis.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDao userDao;

	@Override
	public boolean add(User user) {
		// TODO 自动生成的方法存根
		boolean flag = false;
		try {
			userDao.add(user);
			flag = true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return flag;
	}

	@Override
	public boolean update(User user) {
		// TODO 自动生成的方法存根
		boolean flag = false;
		try {
			userDao.update(user);
			flag = true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return flag;
	}

	@Override
	public boolean delete(int id) {
		// TODO 自动生成的方法存根
		boolean flag = false;
		try {
			userDao.delete(id);
			flag = true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return flag;
	}

	@Override
	public User findById(int id) {
		// TODO 自动生成的方法存根
		return userDao.findById(id);
	}
	
	
}
