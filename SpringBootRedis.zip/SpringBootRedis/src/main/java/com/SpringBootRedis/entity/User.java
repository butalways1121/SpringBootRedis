package com.SpringBootRedis.entity;

import java.io.Serializable;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONType;

@JSONType(orders = { "id", "name", "age" })
public class User implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6288371932409577296L;
	private int id;
	private String name;
	private int age;

	public User() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return JSONObject.toJSONString(this);
	}
}
